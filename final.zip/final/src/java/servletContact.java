import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class servletContact extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection con = null;
        String i_name = request.getParameter("i_name");
        String i_email = request.getParameter("i_email");
         String i_message = request.getParameter("i_message");
         
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
            PreparedStatement ps = con.prepareStatement("insert into a_contact value(?,?,?)");
            ps.setString(1,i_name);
            ps.setString(2,i_email);  
            ps.setString(3,i_message);
        
      
            ps.executeUpdate();
           
            
            
            out.println("Data is inputed successfully.");
        }
        catch (Exception e)
        {e.printStackTrace();}
        finally {
        try {
            con.close();
        }
        catch (Exception e)
        {e.printStackTrace();}
    }
    }
}