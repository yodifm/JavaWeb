import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class servletBuy extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection con = null;
        String b_name = request.getParameter("b_name");
        String b_country = request.getParameter("b_country");
         String b_pos = request.getParameter("b_pos");
         String b_option = request.getParameter("b_option");
         
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
            PreparedStatement ps = con.prepareStatement("insert into a_buy value(?,?,?,?)");
            ps.setString(1,b_name);
            ps.setString(2,b_country);  
            ps.setString(3,b_pos);
            ps.setString(4,b_option);
        
      
            ps.executeUpdate();
           
            
            
            out.println("Data is inputed successfully.");
        }
        catch (Exception e)
        {e.printStackTrace();}
        finally {
        try {
            con.close();
        }
        catch (Exception e)
        {e.printStackTrace();}
    }
    }
}