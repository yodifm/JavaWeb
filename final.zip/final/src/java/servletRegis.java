import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class servletRegis extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection con = null;
        String i_username = request.getParameter("i_username");
        String i_password = request.getParameter("i_password");
         String i_age = request.getParameter("i_age");
         String i_phonenumber = request.getParameter("i_phonenumber");
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
            PreparedStatement ps = con.prepareStatement("insert into a_regis value(?,?,?,?)");
            ps.setString(1,i_username);
            ps.setString(2,i_password);  
            ps.setString(3,i_age);
            ps.setString(4,i_phonenumber);
      
            ps.executeUpdate();
           
            
            
            out.println("Data is inputed successfully.");
        }
        catch (Exception e)
        {e.printStackTrace();}
        finally {
        try {
            con.close();
        }
        catch (Exception e)
        {e.printStackTrace();}
    }
    }
}